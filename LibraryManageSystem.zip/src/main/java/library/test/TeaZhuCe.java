package library.test;

/**
 * Created by Administrator on 2016/11/8.
 */
public class TeaZhuCe implements ZhuCe {
    public void zhuCe() {

    }

    public void deLu() {

    }
}
