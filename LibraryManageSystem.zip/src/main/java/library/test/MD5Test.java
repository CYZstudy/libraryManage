package library.test;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Created by syb on 2016/11/11.
 */
public class MD5Test {
    private final static String[] hexDigits = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f"};

    public static String encryptByMD5(String input) {
        return encryptMD5InputString(input);
    }

    /**
     * ��֤�����Ƿ���ȷ
     *
     * @param MD5String
     * @param initialString
     * @return
     */
    public static boolean verify(String MD5String, String initialString) {
        if (MD5String.equals(encryptMD5InputString(initialString))) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * ��������ַ������MD5����
     *
     * @param inputString
     * @return
     */
    public static String encryptMD5InputString(String inputString) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] bytes = md.digest(inputString.getBytes());
            String restult = byteArrayToHexString(bytes);
            return restult.toUpperCase();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * ��һ���ֽ�����ת��Ϊһ��ʮ�������ַ���
     *
     * @param b �ֽ�����
     * @return
     */
    public static String byteArrayToHexString(byte[] b) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < b.length; i++) {
            sb.append(byteToHexString(b[i]));
        }
        return sb.toString();
    }

    /**
     * ��һ���ֽ�ת��Ϊʮ�������ַ���
     *
     * @param b
     * @return
     */
    public static String byteToHexString(byte b) {
        int n = b;
        if (n < 0) {
            n = b + 256;
        }
        int d1 = n / 16;
        int d2 = n % 16;
        return hexDigits[d1] + hexDigits[d2];
    }

    public static void main(String[] args) {
        String pwd = "123";
        String pwd2 = "";
        pwd2 = encryptByMD5(pwd);
        System.out.println(verify(pwd2,pwd));
    }
}
