package library.test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Created by Administrator on 2016/11/8.
 */
public class CoperationMySql {
    private Connection conStu = Dbcon.connection("");
    private PreparedStatement pst = null;


    /**
     * 修改学生数据库
     * @param sql 修改数据库的语言
     * @return
     */
    public boolean updateSql(String sql){
        try {
            pst = conStu.prepareStatement(sql);
            pst.executeUpdate();
            return true;
        } catch (SQLException e) {
         //   System.out.println("修改数据库出错");
            e.printStackTrace();
        }catch (Exception e){
            System.out.println("修改出错");
            e.printStackTrace();
        }
        return false;
    }
    /**
     * 删除学生数据库
     * @param sql 删除数据库的语言
     * @return
     */
    public boolean delteSql(String sql){
        try {
            pst = conStu.prepareStatement(sql);
            pst.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("删除数据出错");
            e.printStackTrace();
        }catch (Exception e){
            System.out.println("删除出错");
            e.printStackTrace();
        }
        return false;
    }
    /**
     * 插入学生数据库
     * @param sql 数据库操作语言
     * @return
     */
    public boolean insertSql(String sql) {
        try {
            pst = conStu.prepareStatement(sql);
            pst.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("插入数据出错");
            e.printStackTrace();
        }catch (Exception e){
            System.out.println("插入出错");
            e.printStackTrace();
        }
        return false;
    }
}
