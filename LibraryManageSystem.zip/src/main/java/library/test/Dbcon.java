package library.test;

import java.sql.*;

/**
 * Created by Administrator on 2016/11/8.
 */
public class Dbcon {
    public static void main(String[] args) {
        //region ????
        int count = 0;
        try {
            Connection con = connection("library");
            System.out.println("���ӳɹ�");
            Statement statement = con.createStatement();
            String sql1 = "delete  from  chang WHERE  book_id =1 ";
            statement.execute(sql1);
            System.out.println("ɾ���ɹ�");


            // ???��?SQL???
          /*  String sql = "CREATE TABLE ������ (id VARCHAR(255) NOT NULL )";
            con.createStatement().executeUpdate(sql);
            System.out.println("�����ɹ�");
            String sql1 = "select * from student";*/
            // ?????
            ResultSet rs = statement.executeQuery(sql1);
            while (rs.next()) {
                System.out.println(rs.getInt("id") + "\t\t" + rs.getString("name"));
            }


            rs.close();
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        //endregion*/
    }


    /**
     * ????????????????
     */
    public static Connection connection(String sqlName) {
        //???????????
        Connection con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/" + sqlName;
            String user = "root";
            String passWord = "";
            con = DriverManager.getConnection(url, user, passWord);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return con;
    }
}
