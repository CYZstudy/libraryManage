package library.test;

/**
 * Created by Administrator on 2016/11/8.
 */
public class MySqlTest {
    public static void main(String[] args) {
       // Connection con = Dbcon.getConnection();

    }
}
