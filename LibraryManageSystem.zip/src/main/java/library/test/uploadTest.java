package library.test;

import java.io.*;

/**
 * Created by syb on 2016/11/11.
 */
public class uploadTest {
    public static void main(String[] args) {
        uploadFile();
    }

    public static void uploadFile() {
        File file = new File("F:\\work\\info1.txt");
        try {
            FileInputStream fs = new FileInputStream(file);
            InputStreamReader isr = new InputStreamReader(fs, "utf-8");
            BufferedReader bf = new BufferedReader(isr);
            StringBuffer sb = new StringBuffer();
            String test = "";
            while ((test = bf.readLine()) != null) {
                 sb.append(test);
            }
            System.out.println(sb.toString());
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
