package library.test;

/**
 * Created by Administrator on 2016/11/8.
 */
public interface ZhuCe {
   public abstract void zhuCe();
    public abstract void deLu();
}
