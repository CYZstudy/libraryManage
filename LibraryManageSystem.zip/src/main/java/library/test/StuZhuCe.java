package library.test;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

/*
 * Created by Administrator on 2016/11/8.
 */

public class StuZhuCe implements ZhuCe {
    public static void main(String[] args) {
        ZhuCe zhu = new StuZhuCe();
        zhu.zhuCe();
    }
    public void zhuCe() {
        System.out.println("����������û���");
        Scanner scUser = new Scanner(System.in);
        String user = scUser.next();
        System.out.println("�������������");
        Scanner scPwd = new Scanner(System.in);
        String pwdWord = scPwd.next();
        System.out.println("�����������ϵ��ʽ");
        Scanner scNum = new Scanner(System.in);
        String num = scNum.next();
        try {
            Connection con = Dbcon.connection("test");
            if (!con.isClosed()) {
                System.out.println("�������ݿ�ɹ�");
            }
            //  //����һ��Statementִ��sql���
            //   Statement st = con.prepareStatement();
            //  String sql = ""
            Statement statement = con.createStatement();
            // Ҫִ�е�SQL���
            String sql = "insert into teacher (stu_name,stu_pwd,stu_num) values ('zhaohang','45666','44545')";
            con.createStatement().execute(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deLu() {


    }
}
