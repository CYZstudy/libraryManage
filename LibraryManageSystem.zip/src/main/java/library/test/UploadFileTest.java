package library.test;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

/**
 * Created by syb on 2016/11/11.
 */
public class UploadFileTest extends HttpServlet {
    public static final long serialVersionUID = 1L;

    public static void main(String[] args) {

    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        DiskFileItemFactory factory = new DiskFileItemFactory();
        @SuppressWarnings("deprecation")
        String path = request.getRealPath("/upload");
        factory.setSizeThreshold(1024 * 1024);
        ServletFileUpload upload = new ServletFileUpload(factory);
        upload.setSizeMax(-1);
        try {
            List<FileItem> list = upload.parseRequest(request);
            String va = null;
            for (FileItem item : list
                    ) {
                if (item.isFormField()) {
                    va = item.getString("utf-8");
                } else {
                    String value = item.getName();
                    int start = value.lastIndexOf("\\");
                    String fileName = value.substring(start + 1);
                    InputStream in = item.getInputStream();
                    UploadDomain dao = new UploadDomain();
                    int index = fileName.lastIndexOf(".");
                    String realFileName = fileName.substring(0, index);
                    dao.insert(in, realFileName, va, va);
                }
            }
        } catch (FileUploadException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void doPost(HttpServletRequest request, HttpServletResponse re) throws ServletException, IOException {
        doGet(request, re);
    }

}
