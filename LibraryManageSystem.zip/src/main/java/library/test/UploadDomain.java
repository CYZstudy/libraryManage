package library.test;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * Created by syb on 2016/11/11.
 */
public class UploadDomain {
    public void insert(InputStream in, String fileName, String type, String describe) throws Exception {
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        System.out.println(describe);
        con = Dbcon.connection("loadtest");
        String sql = "insert into upload(file,fileName,typ,des) values (" + in + "," + fileName + "," + type + "," + describe + ")";
        pst = con.prepareStatement(sql);
        pst.execute();
        con.close();
    }
}
