package library.libraryManage;

import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by syb on 2016/11/9.
 */
public class Manage extends Person {
    private static String table_name = LibraryInterface.name;
    private static Connection con = DataOperation.connection();
    private static String delBook;
    private static String user = null;
    private static String pwd = null;
    private static int tel = 0;
    private static int numberBook = 0;

    public Manage(String name) {
        Person p = new Person(name);

    }

    public Manage() {

    }



    /**
     * ��ѯͼ��ݲ��� (T)
     */
    public static void showBook() {
        String sql = "select * from book";
        DataOperation.queryBookSql(sql);
        LibraryInterface.manOperation();
    }

    /**
     * �޸�����(T)
     *
     * @param name
     */
    public static void modifyPwd(String name) {
        Scanner scPwd = null;
        try {
            System.out.print("������������");
            scPwd = new Scanner(System.in);
            String newPwd = scPwd.next();
            String sqlModifyPwd = "update manage set man_pwd=" + "'" + newPwd + "'" + " where man_name=" + "'" + name + "'";
            DataOperation.modifySql(sqlModifyPwd);
            System.out.println("�޸ĳɹ�");
        } catch (Exception e) {
            System.out.println("�������");
        }
        LibraryInterface.manOperation();
    }

    /**
     * ע�ᣨT��
     *
     * @param name Ҫע�������
     * @param pwd  ע�������
     * @param tel  ע��ĵ绰
     */
    public static void enroll(String name, String pwd, int tel) {
        if (!queryUser(name)) {
            String sqlZheCe = "insert into manage (man_name,man_pwd,man_tel) values (" + "'" + name + "'" + "," + "'" + pwd + "'" + "," + tel + ")";
            DataOperation.insertSql(sqlZheCe);
            System.out.println("ע��ɹ�");
        } else {
            System.out.println("�Ѵ��ڸ��û�");
        }
    }

    /**
     * ��ѯ�Ƿ�����û�
     *
     * @param user
     * @return
     */
    public static boolean queryUser(String user) {
        String sql = "select * from manage";
        //�洢�鼮��ʷ
        ArrayList<String> teach_name = new ArrayList<String>();
        try {
            ResultSet rs = con.prepareStatement(sql).executeQuery();
            while (rs.next()) {
                teach_name.add(rs.getString("man_name"));
            }
        } catch (SQLException e) {
            System.out.println("��ѯʧ��");
            e.printStackTrace();
        }
        for (int i = 0; i < teach_name.size(); i++) {
            if (teach_name.get(i).equals(user)) {
                return true;
            }
        }
        return false;
    }

    /**
     * ��ѯͼ���Ƿ����ͼ���
     * @param bookName
     * @param bookAuth
     * @return
     */
    public static boolean queryBookIsExist(String bookName, String bookAuth) {
        String sql = "select * from book";
        //�洢�鼮��ʷ
        ArrayList<String> book_name = new ArrayList<String>();
        ArrayList<Integer> book_num = new ArrayList<Integer>();
        ArrayList<String> book_auth = new ArrayList<String>();
        try {
            ResultSet rs = con.prepareStatement(sql).executeQuery();
            while (rs.next()) {
                book_name.add(rs.getString("book_name"));
                book_num.add(rs.getInt("book_number"));
                book_auth.add(rs.getString("book_auth"));
            }
        } catch (SQLException e) {
            System.out.println("��ѯʧ��");
            e.printStackTrace();
        }
        for (int i = 0; i < book_name.size(); i++) {
            if (book_name.get(i).equals(bookName) && book_auth.get(i).equals(bookAuth)) {
                numberBook = book_num.get(i);
                return true;
            }
        }
        return false;
    }

    /**
     * ����ͼ��
     */
    public static void addBookStory() {
        System.out.print("������Ҫ���ӵ�����");
        Scanner scName = new Scanner(System.in);
        String name = scName.next();
        System.out.print("�����������������");
        Scanner scAuth = new Scanner(System.in);
        String auth = scAuth.next();
        System.out.print("����������");
        Scanner scNumber = new Scanner(System.in);
        int numbers = scNumber.nextInt();
        if (queryBookIsExist(name, auth)) {
            numbers = numbers + numberBook;
            //����
            String sqlAdd = "UPDATE book SET book_number=" + numbers + " where book_name=" + "'" + name + "'";
            DataOperation.delteSql(sqlAdd);
        } else {
            String sql = "insert into book (book_name,book_auth,book_number) values (" + "'" + name + "','" + auth + "'," + numbers + ")";
            DataOperation.insertSql(sql);

        }
        System.out.println("���ӳɹ�");
        LibraryInterface.manOperation();
    }

    /**
     * ���չؼ��������鼮
     */
    public static void search() {
        Person.search();
        LibraryInterface.manOperation();
    }

    /**
     * ɾ��ͼ��
     */
    public static void deleteBook() {
        Scanner scBookName = null;
        try {
            System.out.print("��������Ҫɾ���������");
            scBookName = new Scanner(System.in);
            delBook = scBookName.next();
        } catch (Exception e) {
            System.out.println("������󣡣�");
        }
        if (queryHis(delBook)) {
            try {
                String sqldel = "delete  from book WHERE book_name =" + "'" + delBook + "'";
                //�������ݿ�
                PreparedStatement pst = con.prepareStatement(sqldel);
                pst.execute();
                System.out.println("ɾ���ɹ�");
            } catch (Exception e) {
                System.out.println("ɾ��ʧ��");
                e.printStackTrace();
            }
        }
        LibraryInterface.manOperation();
    }

    /**
     * ��ѯɾ��ͼ���Ƿ���ͼ���
     */

    public static boolean queryHis(String delBook) {

        String sql = "select book_name from book";
        //�洢�鼮��ʷ
        ArrayList<String> listBook = new ArrayList<String>();
        try {
            ResultSet rs = con.prepareStatement(sql).executeQuery();
            while (rs.next()) {
                listBook.add(rs.getString("book_name"));
            }
            for (int i = 0; i < listBook.size(); i++) {
                if (listBook.get(i).equals(delBook)) {
                    return true;
                }
            }
        } catch (SQLException e) {
            System.out.println("��ѯʧ��");
            e.printStackTrace();
        }
        return false;
    }

    /**
     * �ϴ��ļ�
     */
    public static void uploadFile(){
        File file = new File("F:\\work\\info.txt");
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            StringBuffer sb = new StringBuffer();
            String text ="";
            while ((text =br.readLine())!=null){
                sb.append(text);
            }
            System.out.println(sb.toString());

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}





