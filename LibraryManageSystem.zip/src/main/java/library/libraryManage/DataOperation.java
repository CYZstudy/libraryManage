package library.libraryManage;

import java.sql.*;
import java.util.ArrayList;

/**
 * Created by Administrator on 2016/11/8.
 */
public class DataOperation {
    private static Connection con = null;
    //����
    private static String url = "jdbc:mysql://localhost:3306/library";
    //����
    private static String drive = "com.mysql.jdbc.Driver";
    //�û���
    private static String user = "root";
    //����
    private static String pwd = "";
    //����һ��statement����������ݿ�
    private static PreparedStatement pst = null;

    /**
     * ���ӵ����ݿ�
     *
     * @return
     */
    public static Connection connection() {
        try {
            //��������
            Class.forName(drive);
            con = DriverManager.getConnection(url, user, pwd);
        } catch (ClassNotFoundException e) {
            System.out.println("��������ʧ��");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("����ʧ��");
            e.printStackTrace();
        }
        return con;
    }

    /**
     * �����ݿ������������
     *
     * @param sql
     */
    public static void insertSql(String sql) {
        try {
            con.prepareStatement(sql).execute();

        } catch (SQLException e) {
            System.out.println("����ʧ��");
            e.printStackTrace();
        }
    }

    /**
     * ��ѯͼ�����ݿ������
     *
     * @param sql
     */
    public static void queryBookSql(String sql) {

        //��Ų�ѯ�������
        ArrayList<String> book_name = new ArrayList<String>();
        //��Ų�ѯ�������
        ArrayList<String> book_auth = new ArrayList<String>();
        //��Ų�ѯ���鼮
        ArrayList<Integer> book_number = new ArrayList<Integer>();
        try {
            ResultSet rs = con.createStatement().executeQuery(sql);
            while (rs.next()) {
                book_name.add(rs.getString("book_name"));
                book_auth.add(rs.getString("book_auth"));
                book_number.add(rs.getInt("book_number"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println("book_name" + "\t" + "book_auth" + "\t" + "book_number");
        for (int i = 0; i < book_name.size(); i++) {
            System.out.println(book_name.get(i) + "\t\t" + book_auth.get(i) + "\t\t" + book_number.get(i));
        }
    }

    /**
     * �޸����ݿ�
     *
     * @param sql
     */
    public static void modifySql(String sql) {

        try {
            pst = con.prepareStatement(sql);
            pst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public static int getNumber(String borrowBook) {
        int number = 0;
        //��Ų�ѯ�������
        ArrayList<String> book_name = new ArrayList<String>();
        //��Ų�ѯ�������
        ArrayList<String> book_auth = new ArrayList<String>();
        //��Ų�ѯ���鼮
        ArrayList<Integer> book_number = new ArrayList<Integer>();
        String sql = "select * from book";
        try {

            ResultSet rs = con.prepareStatement(sql).executeQuery();
            while (rs.next()) {
                book_name.add(rs.getString("book_name"));
                book_auth.add(rs.getString("book_auth"));
                book_number.add(rs.getInt("book_number"));
            }
            //con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        //    System.out.println("book_name" + "\t" + "book_auth" + "\t" + "book_number");
        for (int i = 0; i < book_name.size(); i++) {
            if (book_name.get(i).equals(borrowBook)) {
                number = book_number.get(i);
                return number;
            }
        }
        return number;
    }

    /**
     * ɾ�����ݿ�����
     *
     * @param sql
     */
    public static void delteSql(String sql) {
        try {
            Statement st = con.createStatement();
            st.execute(sql);
        } catch (SQLException e) {
            System.out.println("ɾ��ʧ��");
            e.printStackTrace();
        }
    }
}
