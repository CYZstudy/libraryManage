package library.libraryManage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by syb on 2016/11/9.
 */
public class Teacher extends Person {
    //�洢�����
    private static String borrowBook;
    private static String table_name = LibraryInterface.name;
    private static Connection con = DataOperation.connection();
    private static String returnBook;
    private static String user = null;
    private static String pwd = null;
    private static int tel = 0;

    public Teacher(String name) {
        Person p = new Person(name);

    }

    public Teacher() {

    }

   /* public static void main(String[] args) {

    *//*    Teacher.zhuCe("lisi", "woainisd", 17812255);
        Teacher t = new Teacher("lisi");
        t.showBook();
        t.borrow();
        t.modifyPwd("lisi");
*//*
    }*/

    /**
     * ��ѯͼ��ݲ��� (T)
     */
    public static void showBook() {

        String sql = "select * from book";
        DataOperation.queryBookSql(sql);
        LibraryInterface.teaOperation();
    }

    /**
     * ����(T)
     */
    public static void borrow() {
        int newValue = 0;
        Scanner scBookName = null;
        try {
            System.out.print("��������Ҫ����������");
            scBookName = new Scanner(System.in);
            borrowBook = scBookName.next();
            if (!queryHis(borrowBook)) {
                try {
                    String sqladd = "insert into " + table_name + " (book_his)  values " + "('" + borrowBook + "' ) ";
                    //�������ݿ�
                    DataOperation.insertSql(sqladd);
                } catch (Exception e) {

                }
            }
            newValue = DataOperation.getNumber(borrowBook) - 1;
            String sqldete = "UPDATE book SET book_number=" + newValue + " where book_name=" + "'" + borrowBook + "'";
            DataOperation.delteSql(sqldete);
        } catch (Exception e) {
            System.out.println("������󣡣�");
        }
        System.out.println("����ɹ�");
        LibraryInterface.teaOperation();
    }

    /**
     * �޸�����(T)
     *
     * @param name
     */
    public static void modifyPwd(String name) {
        Scanner scPwd = null;
        try {
            System.out.print("������������");
            scPwd = new Scanner(System.in);
            String newPwd = scPwd.next();
            String sqlModifyPwd = "update teacher set tea_pwd=" + "'" + newPwd + "'" + " where tea_name=" + "'" + name + "'";
            DataOperation.modifySql(sqlModifyPwd);
            System.out.println("�޸ĳɹ�");
        } catch (Exception e) {
            System.out.println("�������");
        }
        LibraryInterface.teaOperation();
    }

    /**
     * ע�ᣨT��
     *
     * @param name Ҫע�������
     * @param pwd  ע�������
     * @param tel  ע��ĵ绰
     */
    public static void enroll(String name, String pwd, int tel) {
        if (!queryUser(name)) {
            String sqlZheCe = "insert into teacher (tea_name,tea_pwd,tea_tel) values (" + "'" + name + "'" + "," + "'" + pwd + "'" + "," + tel + ")";
            DataOperation.insertSql(sqlZheCe);
            System.out.println("ע��ɹ�");
        } else {
            System.out.println("�Ѵ��ڸ��û�");
        }
    }

    /**
     * ��ѯ������ʷ(T)
     */
    public static void queryHis() {
        String sql = "select * from " + table_name;
        //�洢�鼮��ʷ
        ArrayList<String> book = new ArrayList<String>();
        try {
            ResultSet rs = con.prepareStatement(sql).executeQuery();
            while (rs.next()) {
                book.add(rs.getString("book_his"));
            }
            System.out.println("��Ľ�����ʷΪ");
            for (int i = 0; i < book.size(); i++) {
                System.out.println(book.get(i));
            }
        } catch (SQLException e) {
            System.out.println("��ѯʧ��");
            e.printStackTrace();
        }
        LibraryInterface.teaOperation();
    }

    /**
     * ������ʷ�Ƿ��Ѿ����ڸ���
     *
     * @param borrowBook
     * @return
     */
    public static boolean queryHis(String borrowBook) {
        String sql = "select * from " + table_name;
        //�洢�鼮��ʷ
        ArrayList<String> list_book = new ArrayList<String>();
        try {
            ResultSet rs = con.prepareStatement(sql).executeQuery();
            while (rs.next()) {
                list_book.add(rs.getString("book_his"));
            }
            for (int i = 0; i < list_book.size(); i++) {
                if (list_book.get(i).equals(borrowBook)) {
                    return true;
                }
            }
        } catch (SQLException e) {
            System.out.println("��ѯʧ��");
            e.printStackTrace();
        }
        return false;
    }

    /**
     * ��ѯ�Ƿ�����û�
     *
     * @param user
     * @return
     */
    public static boolean queryUser(String user) {
        String sql = "select * from teacher";
        //�洢�鼮��ʷ
        ArrayList<String> teach_name = new ArrayList<String>();
        try {
            ResultSet rs = con.prepareStatement(sql).executeQuery();
            while (rs.next()) {
                teach_name.add(rs.getString("tea_name"));
            }
        } catch (SQLException e) {
            System.out.println("��ѯʧ��");
            e.printStackTrace();
        }
        for (int i = 0; i < teach_name.size(); i++) {
            if (teach_name.get(i).equals(user)) {
                return true;
            }
        }
        return false;
    }

    /**
     * ���չؼ��������鼮
     */
    public static void search() {
        Person.search();
        LibraryInterface.teaOperation();
    }

    /**
     * ����
     */
    public static void returnBook() {
        int num = 0;
        Scanner scBookName = null;
        try {
            System.out.print("��������Ҫ�����������");
            scBookName = new Scanner(System.in);
            returnBook = scBookName.next();
        } catch (Exception e) {
            System.out.println("������󣡣�");
        }

        if (queryHis(returnBook)) {
            try {
                String sqldel = "delete  from " + table_name + " WHERE  book_his =" + "'" + returnBook + "'";
                //�������ݿ�
                PreparedStatement pst = con.prepareStatement(sqldel);
                pst.execute();
               // System.out.println("ɾ���ɹ�");
            } catch (Exception e) {
                System.out.println("ɾ��ʧ��");
                e.printStackTrace();
            }

            num = DataOperation.getNumber(returnBook) + 1;
            String sqldete = "UPDATE book SET book_number=" + num + " where book_name=" + "'" + returnBook + "'";
            DataOperation.delteSql(sqldete);
            System.out.println("����ɹ�");
            LibraryInterface.teaOperation();
        }
    }
}




