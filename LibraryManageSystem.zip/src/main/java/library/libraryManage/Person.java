package library.libraryManage;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by syb on 2016/11/9.
 */
public class Person {
    private static Connection con = DataOperation.connection();
    public static int begin = 0;
    public static int increase = 4;
    public static int end = 2;

    public Person() {
    }

    /**
     * �ж��Ƿ���ڱ�
     *
     * @param name
     * @return
     */
    public static boolean HasTable(String name) {
        //�ж�ĳһ�����Ƿ����
        boolean result = false;
        try {
            DatabaseMetaData meta = con.getMetaData();
            ResultSet set = meta.getTables(null, null, name, null);
            while (set.next()) {
                result = true;
            }
        } catch (Exception eHasTable) {
            System.err.println(eHasTable);
            eHasTable.printStackTrace();
        }
        return result;
    }

    /**
     * ����������ʷ��¼��
     *
     * @param name
     */
    public Person(String name) {
        String sql = "create table " + name + " (book_his VARCHAR(100) not null,book_id INT NOT NULL ) ";
        try {
            con.createStatement().executeUpdate(sql);

        } catch (SQLException e) {
            System.out.println("�������ݱ�ʧ��");
            e.printStackTrace();
        }
    }

    /**
     * ��ѯ���ݿ����Ƿ�����û�
     *
     * @param sql   �������ݿ������
     * @param _name ��ѯ�ı���label_name��ǩ
     * @param _pwd  ��ѯ ���label_pwd��ǩ
     * @param name  ��ѯ������
     * @param pwd   ��ѯ������
     * @return
     */
    public static boolean queryIsDengLu(String sql, String _name, String _pwd, String name, String pwd) {
        //�洢����
        ArrayList<String> list_name = new ArrayList<String>();
        //�洢����
        ArrayList<String> list_pwd = new ArrayList<String>();
        try {
            ResultSet rs = con.prepareStatement(sql).executeQuery();
            while (rs.next()) {
                list_name.add(rs.getString(_name));
                list_pwd.add(rs.getString(_pwd));
            }
            for (int i = 0; i < list_name.size(); i++) {
                if (list_name.get(i).equals(name) && MD5.verify(list_pwd.get(i), pwd)) {
                    System.out.println("��¼�ɹ�");
                    return true;
                } else if (list_name.get(i).equals(name)) {
                    continue;
                } else if (MD5.verify(list_pwd.get(i), pwd)) {
                    continue;
                }
            }

            //  con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    /**
     * ���ؼ�������
     */
    public static void search() {
        System.out.println("��ѡ��Ҫ�����Ĺؼ���");
        System.out.println("1������");
        System.out.print("2������");
        Scanner scNum = new Scanner(System.in);
        int num = scNum.nextInt();
        if (num == 1) {
            System.out.print("������Ҫ��ѯ������");
            Scanner scName = new Scanner(System.in);
            String name = scName.next();
            String sql = "SELECT book_name,book_auth,book_number FROM book WHERE book_name ='" + name + "'";
            DataOperation.queryBookSql(sql);

        } else if (num == 2) {
            System.out.print("������Ҫ��ѯ������");
            Scanner scAuth = new Scanner(System.in);
            String auth = scAuth.next();
            String sql = "SELECT  book_name,book_auth,book_number FROM book WHERE book_auth='" + auth + "'";
            DataOperation.queryBookSql(sql);
        }
    }
}
