package library.libraryManage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by syb on 2016/11/9.
 */
public class student extends Person {
    //�洢�����
    private static String borrowBook;
    private static String returnBook;
    private static int begin = 0;
    private static int increaseCount = 1;
    private static int end = begin + increaseCount;
    private static int count = 0;
    private static String table_name = LibraryInterface.name;
    private static Connection con = DataOperation.connection();

    private static String user = null;
    private static String pwd = null;
    private static int tel = 0;

    public student(String name) {
        Person p = new Person(name);

    }

   /* public static void main(String[] args) {
      *//*  //region ����ע��
      *//**//*  table_name = "zhangsan";
        System.out.print("�������˺�");
        Scanner scUser = new Scanner(System.in);
        user = scUser.next();
        System.out.print("����������");
        Scanner scPwd = new Scanner(System.in);
        pwd = scPwd.next();
        System.out.print("��������ϵ��ʽ");
        Scanner scTel = new Scanner(System.in);
        tel = scTel.nextInt();
        zhuCe(user, pwd, tel);*//**//*
        //endregion
        //  modifyPwd("wangsan");
        table_name = "zhangsan";
        borrow();*//*
    }
*/

    /**
     * ��ѯͼ��ݲ��� (T)
     */
    public static void showBook() {
        String sql = "select book_name,book_auth,book_number from book ";
        DataOperation.queryBookSql(sql);
        LibraryInterface.stuOperation();
    }

    /**
     * ����(T)
     */
    public static void borrow() {
        int newValue = 0;
        Scanner scBookName = null;
        try {
            System.out.print("��������Ҫ����������");
            scBookName = new Scanner(System.in);
        } catch (Exception e) {
            System.out.println("������󣡣�");
        }
        borrowBook = scBookName.next();
        if (!queryHis(borrowBook)) {
            try {
                String sqladd = "insert into " + table_name + " (book_his,book_id)  values " + "('" + borrowBook + "' ," + count + ") ";
                count++;
                //�������ݿ�
                DataOperation.insertSql(sqladd);
            } catch (Exception e) {

            }
        }
        newValue = DataOperation.getNumber(borrowBook) - 1;
        String sqldete = "UPDATE book SET book_number=" + newValue + " where book_name=" + "'" + borrowBook + "'";
        DataOperation.delteSql(sqldete);
        System.out.println("����ɹ�");
        LibraryInterface.stuOperation();
    }

    /**
     * �޸�����(T)
     *
     * @param name
     */
    public static void modifyPwd(String name) {
        Scanner scPwd = null;
        try {
            System.out.print("������������");
            scPwd = new Scanner(System.in);
        } catch (Exception e) {
            System.out.println("�������");
        }
        String newPwd = scPwd.next();
        String sqlModifyPwd = "update student set stu_pwd=" + "'" + newPwd + "'" + " where stu_name=" + "'" + name + "'";
        DataOperation.modifySql(sqlModifyPwd);
        System.out.println("�޸ĳɹ�");
        LibraryInterface.stuOperation();
    }

    /**
     * ע�ᣨT��
     *
     * @param name Ҫע�������
     * @param pwd  ע�������
     * @param tel  ע��ĵ绰
     */
    public static void enroll(String name, String pwd, int tel) {
        if (!queryUser(name)) {
            String sqlZheCe = "insert into student (stu_name,stu_pwd,stu_tel) values (" + "'" + name + "'" + "," + "'" + pwd + "'" + "," + tel + ")";
            DataOperation.insertSql(sqlZheCe);
            System.out.println("ע��ɹ�");
        }else {
            System.out.println("�Ѵ��ڸ��û�");
        }
    }

    /**
     * ��ѯ������ʷ(T)
     */
    public static void queryHis() {
        String sql = "select * from " + table_name;
        //�洢�鼮��ʷ
        ArrayList<String> book = new ArrayList<String>();
        try {
            ResultSet rs = con.prepareStatement(sql).executeQuery();
            while (rs.next()) {
                book.add(rs.getString("book_his"));
            }
        } catch (SQLException e) {
            System.out.println("��ѯʧ��");
            e.printStackTrace();
        }
        System.out.println("��Ľ�����ʷΪ");
        for (int i = 0; i < book.size(); i++) {
            System.out.println(book.get(i));
        }
        LibraryInterface.stuOperation();
    }

   /* public static boolean query() {
        String sql1 = "select * from " + table_name;
        //�洢�鼮��ʷ
        ArrayList<String> book = new ArrayList<String>();
        try {
            ResultSet rs = con.prepareStatement(sql1).executeQuery();
            while (rs.next()) {
                book.add(rs.getString("book_his"));
            }
        } catch (SQLException e) {
            System.out.println("��ѯʧ��");
            e.printStackTrace();
        }

        for (int i = 0; i < book.size(); i++) {
            if (book.get(i).equals(returnBook)) {
                return true;
            }
        }
        return false;
    }*/

    /**
     * ������ʷ�Ƿ��Ѿ����ڸ���
     *
     * @param borrowBook
     * @return
     */
    public static boolean queryHis(String borrowBook) {
        String sql = "select * from " + table_name;
        //�洢�鼮��ʷ
        ArrayList<String> books = new ArrayList<String>();
        try {
            ResultSet rs = con.prepareStatement(sql).executeQuery();
            while (rs.next()) {
                books.add(rs.getString("book_his"));
            }
        } catch (SQLException e) {
            System.out.println("��ѯʧ��");
            e.printStackTrace();
        }
        for (int i = 0; i < books.size(); i++) {
            if (books.get(i).equals(borrowBook)) {
                return true;
            }
        }
        return false;
    }

    /**
     * ��ѯ�Ƿ�����û�
     *
     * @param user
     * @return
     */
    public static boolean queryUser(String user) {
        String sql = "select * from student";
        //�洢��ʷ
        ArrayList<String> list_name = new ArrayList<String>();
        try {
            ResultSet rs = con.prepareStatement(sql).executeQuery();
            while (rs.next()) {
                list_name.add(rs.getString("stu_name"));
            }
        } catch (SQLException e) {
            System.out.println("��ѯʧ��");
            e.printStackTrace();
        }
        for (int i = 0; i < list_name.size(); i++) {
            if (list_name.get(i).equals(user)) {
                return true;
            }
        }
        return false;
    }

    /**
     * ���չؼ��������鼮
     */
    public static void search() {
        Person.search();
        LibraryInterface.stuOperation();
    }

    /**
     * ����
     */
    public static void returnBook() {
        int value = 0;
        Scanner scBookName = null;
        try {
            System.out.print("��������Ҫ�����������");
            scBookName = new Scanner(System.in);
            returnBook = scBookName.next();
        } catch (Exception e) {
            System.out.println("������󣡣�");
        }

        if (queryHis(returnBook)) {
            try {
                String sqldel = "delete  from " + table_name + " WHERE  book_his =" + "'" + returnBook + "'";
                //�������ݿ�
                PreparedStatement pst = con.prepareStatement(sqldel);
                pst.execute();
                System.out.println("ɾ���ɹ�");
            } catch (Exception e) {
                System.out.println("ɾ��ʧ��");
                e.printStackTrace();
            }

            value = DataOperation.getNumber(returnBook) + 1;
            String sqldete = "UPDATE book SET book_number=" + value + " where book_name=" + "'" + returnBook + "'";
            DataOperation.delteSql(sqldete);
            System.out.println("����ɹ�");
            LibraryInterface.stuOperation();
        }
    }
}

