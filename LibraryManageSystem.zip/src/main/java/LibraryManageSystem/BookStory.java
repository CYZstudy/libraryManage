package LibraryManageSystem;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by syb on 2016/11/7.
 */
public class BookStory {
    public static Map<String, Integer> bookStrory = new HashMap<String, Integer>();


}
