package LibraryManageSystem;

/**
 * Created by syb on 2016/11/7.
 */
public class StudentVisit extends Visit {
    public StudentVisit(String name){
        visit(name);
    }
}
