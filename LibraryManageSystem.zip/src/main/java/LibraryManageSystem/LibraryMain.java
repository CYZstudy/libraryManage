package LibraryManageSystem;

import java.util.*;

/**
 * Created by syb on 2016/11/7.
 */
public class LibraryMain {
    //存储书籍，书为键，数量为值
    //存储书籍的名称
    private static List<String> bookList = new ArrayList<String>();
    //存储用户的借阅记录
    private static Map<String, List<String>> uesrManage = new HashMap<String, List<String>>();
    //存储姓名
    private static String id = null;
    //存储密码
    private static String pwd = null;
    //存储借阅历史
    private static List<String> bookHistory = new ArrayList<String>();
    private static BookStory bs = new BookStory();

    public static void main(String[] args) {
        visitSystem();
        System.out.println("请选择你的身份");
        Scanner scNumber = new Scanner(System.in);
        switch (scNumber.nextInt()) {
            case 1:
                new TeacherVisit("");
                Scanner scTeacherSelect = new Scanner(System.in);
                if (scTeacherSelect.nextInt() == 1) {
                    System.out.println("请输入用户名和密码");
                    Scanner scId = new Scanner(System.in);
                    String scid = scId.next();
                    Scanner scPwd = new Scanner(System.in);
                    String scpwd = scPwd.next();
                    deLu(scid, scpwd);
                } else if (scTeacherSelect.nextInt() == 2) {
                    enroll();
                } else if (scTeacherSelect.nextInt() == 3) {
                    visitSystem();
                }
                break;
            case 2:
                new StudentVisit("");
                Scanner scStudentSelect = new Scanner(System.in);
                if (scStudentSelect.nextInt() == 1) {

                } else if (scStudentSelect.nextInt() == 2) {
                    enroll();
                } else if (scStudentSelect.nextInt() == 3) {
                    visitSystem();
                }
                break;
            case 3:
                new ManagerVisit("");

        }

    }



    /**
     * 增加图书
     */
    public static void addBook() {
        try {
            System.out.println("请输入你想要增加图书的种类");
            Scanner scKind = new Scanner(System.in);
            //    System.out.println("是否退出");
            System.out.println("请输入你要增加的数量");
            Scanner scNumber = new Scanner(System.in);
            bs.bookStrory.put(scKind.next(), scNumber.nextInt());
            // Scanner scIsExit = new Scanner(System.in);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * 删除书籍
     */
    public static void deleteBook() {

        showBook(bs.bookStrory);
        System.out.println("请输入你想删除书的名字");
        Scanner scBookName = new Scanner(System.in);
        String scbn = scBookName.next();
        // System.out.println("请输入你想删除书的数量");

        //  Scanner scBookNumber = new Scanner(System.in);
        // int sbn = scBookNumber.nextInt();
        /*if (scBookNumber.nextInt() > BookStory.getBookStrory().get(scBookName).intValue()) {
            System.out.println("输入数字超出库存数量，请重新输入");
            scBookNumber = new Scanner(System.in);
        }*/
        //int sbn1 = bs.bookStrory.get(scBookName) - sbn;
        bs.bookStrory.put(scbn, bs.bookStrory.get(scbn) - 1);
        System.out.println("删除成功");
    }


    /**
     * 查看借阅历史
     *
     * @param user
     */
    public static void checkHistory(String user) {
        int i = 1;
        List<String> checkHistory = uesrManage.get(user);
        System.out.println("你的借阅历史为：");
        for (String c : checkHistory
                ) {
            System.out.println("序号：" + i + "书名：" + c);
            i++;
        }
        System.out.println("是否返回上一层");
        Scanner scIsReturn = new Scanner(System.in);
        if (scIsReturn.equals("是")) {
            user();
        }
    }

    /**
     * 展示图书
     *
     * @param listBook
     */
    public static void showBook(Map<String, Integer> listBook) {
        int i = 1;
        for (Map.Entry<String, Integer> entry : listBook.entrySet()
                ) {
            System.out.println("序号：" + i + " " + "书籍名称：" + entry.getKey() + " " + "书籍的数量： " + entry.getValue());
        }
    }

    /**
     * 借书
     */
    public static void borrowBook() {
        System.out.println("请输入你想要借的书");
        showBook(bs.bookStrory);
        Scanner scBook = new Scanner(System.in);
        String bookBorrow = bookList.remove(scBook.nextInt());
        System.out.println("你想要借的书是：" + bookBorrow);
        bs.bookStrory.put(bookBorrow, bs.bookStrory.get(bookBorrow).intValue() - 1);
        if (bs.bookStrory.get(bookBorrow).intValue() == 0) {
            bookList.remove(bookList.indexOf(bookBorrow));
        }
        bookHistory.add(bookBorrow);
        uesrManage.put(id, bookHistory);
        System.out.println("是否返回上一层");
        Scanner scIsReturn = new Scanner(System.in);
        if (scIsReturn.equals("是")) {
            user();
        }
    }

    /**
     * 登录
     */
    public static void enroll() {

    }

    public static void deLu(String scId, String pwd) {

        if (id.equals("admin") && pwd.equals("123456")) {
            while (true) {
                manage();
                Scanner scNum = new Scanner(System.in);
                int input = scNum.nextInt();
                try {
                    if (input == 1) {
                        addBook();
                    } else if (input == 2) {
                        deleteBook();
                        //删除图书
                    } else if (input == 3) {
                        return;
                    }
                } catch (InputMismatchException e) {
                    e.printStackTrace();
                }
            }
        } else if (id.equals("user") && pwd.equals("000000")) {
            while (true) {
                user();
                Scanner scNum = new Scanner(System.in);
                int in = scNum.nextInt();
                switch (in) {
                    case 1:
                        checkHistory(id);//查看借阅图书
                        break;
                    case 2:
                        borrowBook();//借阅图书
                        break;
                    case 3:
                        return;
                }
            }
        }
    }

    /**
     * 访问
     */
    public static void visitSystem() {
        System.out.println("-----------欢迎来到图书馆管理系统--------------");
        System.out.println("请选择你的身份：");
        System.out.println("1、教师");
        System.out.println("2、学生");
        System.out.println("3、管理员");
    }


    public static void manage() {
        System.out.println("-----------------欢迎来到管理员界面-------------------------");
        System.out.println("----你可以使用图书馆有以下几个功能：--------------------------");
        System.out.println("----1.增加图书----------------------------------------------");
        System.out.println("----2.删除图书----------------------------------------------");
        System.out.println("----3.退出----------------------------------------------");
        System.out.println("----请选择你要使用的功能-------------------------------------");
    }

    public static void user() {
        System.out.println("-----------------欢迎来到图书馆用户界面----------------------");
        System.out.println("----你可以使用图书馆有以下几个功能：--------------------------");
        System.out.println("----1.查看借阅图书-------------------------------------------");
        System.out.println("----2.借阅图书----------------------------------------------");
        System.out.println("----3.退出--------------------------------------------------");
        System.out.println("----请选择你要使用的功能-------------------------------------");
    }
}
