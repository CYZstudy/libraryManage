package LibraryManageSystem;

/**
 * Created by syb on 2016/11/7.
 */
public class ManagerVisit extends Visit {
    public ManagerVisit(String name) {
        visit(name);
    }
}
