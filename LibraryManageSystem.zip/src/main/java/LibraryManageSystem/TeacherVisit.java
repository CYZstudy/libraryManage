package LibraryManageSystem;

/**
 * Created by syb on 2016/11/7.
 */
public class TeacherVisit extends Visit {
    public TeacherVisit(String name){
        visit(name);
    }

}
