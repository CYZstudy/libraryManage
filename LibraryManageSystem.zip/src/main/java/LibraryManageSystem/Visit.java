package LibraryManageSystem;

import java.util.Scanner;

/**
 * Created by syb on 2016/11/7.
 */
public class Visit {
    public void visit(String name) {
        System.out.println("-----------" + name + "你好，欢迎来到图书系统----------");
        System.out.println(name + ",你可以使用的功能如下：");
        System.out.println("1、登录");
        System.out.println("2、注册");
        System.out.println("3、退出");
    }
    public void delu(String id,String pwd){
        System.out.println("请输入用户名和密码");
        Scanner scteacherId = new Scanner(System.in);
        String scId = scteacherId.next();
        Scanner scTeacherPwd = new Scanner(System.in);
        String scPwd = scTeacherPwd.next();
    }
}
